# LivingMath / UDAV — приемка формальных языков, 2026-11-07

Пакет содержит результаты **реально выполненных MCP-запусков** и отдельные **ещё не запущенные** синтетические сценарии. Ни одна синтетическая таблица не выдаётся за результат сервера.

- `REPORT_RU.md` — фактический RCA, матрица приёмки и граница выводов.
- `protocol/LIVE_RUNS.json` — неизменяемые идентификаторы живых серверных прогонов и digest-и.
- `protocol/ACCEPTANCE_PROTOCOL_RU.md` — расширенная программа исследования формальных языков.
- `protocol/NEXT_KERNEL_REQUIREMENTS_RU.md` — точечные требования к возможной следующей версии ядра, **не выполненные** в этой приёмке.
- `src/generate_datasets.py` — автономная генерация синтетических корпусов (stdlib Python, без сервера).
- `src/test_oracles.py` — независимый контроль генератора, границ `source` и хешей.
- `datasets/*.train.json` — *только обучающие* примеры с метками.
- `datasets/*.queries.json` — *только тестовые* строки **без меток**.
- `datasets/fixture_manifest.json` — публичный локальный манифест, содержащий счётчики скрытых истинных меток (не отправлять вместе с запросом предсказания на сервер).

Контракт вызова: `white_star_symbolic_dataset_store` для `kind=train` и `kind=queries`; затем `white_star_symbolic_observer_synthesize` с `train_ref`, `predict_ref`, `holdout_labels_visible=false`, `enabled_builtins=[]`, `mode=role_branching_ast` либо `mode=auto`.

Локальная проверка:

```bash
python3 src/generate_datasets.py
python3 src/test_oracles.py
```

Создать проект заранее `assurance_project_new`. Фиксированные исходные данные живых прогонов — см. `protocol/LIVE_RUNS.json`; новый прогон создаёт новый `run_id` и требует нового `request_key`.

**Не путать:** текущая система `CHECKED_INSTANCE` — конечная проверка свидетельства, а не универсальная теорема о грамматике. Выход `NO_VERIFIABLE_NEW_OBSERVER` — отсутствие совместимого наблюдателя в допустимом конечном пространстве, а не доказательство неразрешимости языка.
