#!/usr/bin/env python3
"""Independent local consistency checks; not an MCP run."""
import hashlib, json
from pathlib import Path
from generate_datasets import canonical_json, digest, is_dyck2, is_anbn, is_evenpal, is_evena
root=Path(__file__).resolve().parent.parent/'datasets'
for path in sorted(root.glob('*.train.json'))+sorted(root.glob('*.queries.json')):
    data=json.loads(path.read_text(encoding='utf-8'))
    old=data.pop('sha256')
    assert old==digest(canonical_json(data)),path
    for row in data['records']:
        s=' '.join(row['tokens'])
        assert s==row['source']['text'],(path,row['id'])
        assert digest(s)==row['source']['sha256'],(path,row['id'])
        assert ('accepted' in row)==(data['kind']=='train')
assert is_dyck2(tuple('SAPB')) is False
assert is_dyck2(tuple('SABP')) is True
assert is_dyck2(tuple('SPAB')) is True
assert is_anbn(tuple('aabb')) is True
assert is_anbn(tuple('abab')) is False
assert is_evenpal(tuple('abba')) is True
assert is_evenpal(tuple('abab')) is False
assert is_evena(tuple('abbb')) is False
assert is_evena(tuple('aabb')) is True
print('PASS: dataset hashes, token/source spans, blinded queries, reference oracles')
