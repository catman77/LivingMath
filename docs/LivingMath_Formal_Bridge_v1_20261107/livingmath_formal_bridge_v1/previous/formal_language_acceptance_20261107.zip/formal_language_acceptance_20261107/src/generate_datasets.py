#!/usr/bin/env python3
"""Reproducible synthetic formal-language acceptance fixtures for LivingMath v0.4.8.

No model predictions are computed here. Independent gold membership is used to
label TRAIN ONLY; the server sees no labels in query datasets.
"""
from __future__ import annotations
import hashlib
import itertools
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent.parent / 'datasets'
OUT.mkdir(exist_ok=True)

def digest(text: str) -> str:
    return hashlib.sha256(text.encode('utf-8')).hexdigest()

def canonical_json(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False)

def wordset(alphabet: str, lengths: tuple[int, ...]):
    for n in lengths:
        yield from itertools.product(alphabet, repeat=n)

def is_dyck(word, pairs: dict[str, str]):
    reverse = {v:k for k,v in pairs.items()}
    stack = []
    for token in word:
        if token in pairs:
            stack.append(token)
        elif token in reverse:
            if not stack or stack.pop() != reverse[token]:
                return False
        else:
            return False
    return not stack

def is_anbn(w):
    n = len(w)//2
    return len(w)%2 == 0 and n >= 1 and w == ('a',)*n + ('b',)*n

def is_evenpal(w):
    return len(w)>0 and len(w)%2 == 0 and tuple(w) == tuple(reversed(w))

def is_evena(w):
    return sum(x == 'a' for x in w)%2 == 0

def is_abstar(w):
    return len(w)>0 and len(w)%2 == 0 and all(w[i:i+2] == ('a','b') for i in range(0,len(w),2))

def is_dyck1(w):
    return is_dyck(w, {'a':'b'})

def is_dyck2(w):
    return is_dyck(w, {'S':'P','A':'B'})

def is_marked_reverse(w):
    return w.count('#') == 1 and w.index('#') >= 1 and w.index('#') < len(w)-1 and w[:w.index('#')] == tuple(reversed(w[w.index('#')+1:]))

def is_anbncn(w):
    n = len(w)//3
    return n>=1 and len(w)%3==0 and w == ('a',)*n + ('b',)*n + ('c',)*n

def make_records(words, is_train:bool, oracle):
    result=[]
    for i, word in enumerate(words):
        w = tuple(word)
        source = ' '.join(w)
        row = {'id': ('tr-' if is_train else 'qu-')+str(i).zfill(4),
               'source':{'text':source,'sha256':digest(source),
                         'edition':'synthetic-v1','rights':'synthetic-original'},
               'tokens':list(w)}
        if is_train:
            row['accepted'] = bool(oracle(w))
        result.append(row)
    return result

def dataset(kind, words, oracle):
    obj={'schema':'livingmath-observer-dataset/1','kind':kind,
         'records':make_records(words,kind=='train',oracle)}
    obj['sha256']=digest(canonical_json(obj))
    return obj

def save(name, train_words, query_words, oracle, note):
    train=dataset('train',train_words,oracle)
    query=dataset('queries',query_words,oracle)
    assert all('accepted' not in r for r in query['records'])
    for kind,obj in [('train',train),('queries',query)]:
        path=OUT/f'{name}.{kind}.json'
        path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    return {'language':name,'description':note,
            'train_records':len(train_words),'train_positive':sum(map(oracle,train_words)),
            'query_records':len(query_words),'query_positive_oracle_private':sum(map(oracle,query_words)),
            'train_dataset_sha256':train['sha256'],'query_dataset_sha256':query['sha256'],
            'train_ref_live':None,'query_ref_live':None,'run_id_live':None,
            'status':'FIXTURES_ONLY; not automatically executed'}

# Exactly the finite data shapes used in new live experiments; ASCII lexical ordering.
train_binary=list(wordset('ab',(2,4,6)))
query_binary=list(wordset('ab',(8,)))
manifest=[]
manifest.append(save('cfg_anbn',train_binary,query_binary,is_anbn,
    'Nonregular context-free a^n b^n, n>=1'))
manifest.append(save('cfg_even_palindrome',train_binary,query_binary,is_evenpal,
    'Even palindromes w reverse(w), w nonempty'))
manifest.append(save('regular_even_a',train_binary,query_binary,is_evena,
    'Regular language with even number of a tokens'))
manifest.append(save('regular_ab_plus',train_binary,query_binary,is_abstar,
    'Regular language (ab)+, finite-state and right-linear'))
manifest.append(save('cfg_dyck1',train_binary,query_binary,is_dyck1,
    'Dyck(1) a/b bracket roles'))

# New Dyck(2) fixtures are NOT asserted to duplicate the previous chat's
# 174/256 historical sample. Explicit selection is locked here.
d2_train_all=list(wordset('SPAB',(2,4)))
d2_pos=[w for w in d2_train_all if is_dyck2(w)]
d2_neg=[w for w in d2_train_all if not is_dyck2(w)]
d2_train=d2_pos[:10]+d2_neg[:164]
d2_len6=list(wordset('SPAB',(6,)))
d2_qpos=[w for w in d2_len6 if is_dyck2(w)]
d2_qneg=[w for w in d2_len6 if not is_dyck2(w)]
assert len(d2_train)==174 and len(d2_qpos)==40
manifest.append(save('cfg_dyck2_new_stratified',d2_train,d2_qpos+d2_qneg[:216],is_dyck2,
    'Two typed bracket roles; NEW deterministic 174/256 fixtures, not historical frozen set'))

# Marked palindrome: show variable pair matching around delimiter.
marked_train=list(wordset('ab',(1,2)))
marked_train=[p+('#',)+q for p in marked_train for q in wordset('ab',(len(p),))]
marked_query=[p+('#',)+q for p in wordset('ab',(3,)) for q in wordset('ab',(3,))]
manifest.append(save('cfg_marked_palindrome',marked_train,marked_query,is_marked_reverse,
    'Context-free language {w # reverse(w)}; test variable token dependencies'))

# Non-context-free canary: finite membership is decidable and can be memorized;
# correct finite predictions do not certify discovery of a CFG.
tri_train=list(wordset('abc',(3,6)))[:256]
tri_query=[tuple('aaabbbccc')]+[w for w in wordset('abc',(9,)) if w!=tuple('aaabbbccc')][:255]
manifest.append(save('noncfg_anbncn_canary',tri_train,tri_query,is_anbncn,
    'Non-CFL a^n b^n c^n: only a canary for false universal-CFG claims'))

# Targeted epsilon probe: the n>=1 target rejects ε, but the inferred EPS-base AST accepts it.
epsilon_probe=dataset('queries',[tuple()],is_anbn)
(OUT/'cfg_anbn_epsilon.queries.json').write_text(
    json.dumps(epsilon_probe,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')

path=OUT/'fixture_manifest.json'
path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
print('generated',len(manifest),'test suites,',len(list(OUT.glob('*.json'))),'json files')
for m in manifest:
    print(m['language'],m['train_records'],m['train_positive'],m['query_records'],m['query_positive_oracle_private'])
