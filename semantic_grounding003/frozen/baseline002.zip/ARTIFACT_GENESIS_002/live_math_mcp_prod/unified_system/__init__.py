"""Additive SUTI–Bridge–LivingMath endpoint over the accepted RC020 core."""
VERSION = '1.1.0-unified.1'
