"""Bind the automatic proposal/check policy independently from historical certificates."""
from pathlib import Path
import hashlib

from davcore.ast import digest
from davcore.versioning import backend_binding


def policy_binding() -> str:
    root = Path(__file__).parent
    return digest({'DAV_backend': backend_binding(), 'coordinator': {
        name: hashlib.sha256((root/name).read_bytes()).hexdigest()
        for name in ['contract.py', 'journal.py', 'planner.py', 'checker.py', 'controller.py', 'intake.py', 'versioning.py']}})
