#!/usr/bin/env bash
set -eu
LM_AG_BUNDLE_ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
LM_AG_REPLAY_PYTHON="${LM_AG_REPLAY_PYTHON:-python3}"
if [ "$#" -ne 1 ]; then
  printf 'Usage: LM_AG_REPLAY_PYTHON=/path/to/pinned/python bash reproduce.sh /new/private/output\n' >&2
  exit 2
fi
exec "$LM_AG_REPLAY_PYTHON" -I -B "$LM_AG_BUNDLE_ROOT/live_math_mcp_prod/artifact_genesis/replay.py" \
  --bundle "$LM_AG_BUNDLE_ROOT" --out "$1"
