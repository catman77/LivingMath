# Existing API compatibility

Public HTTPS/OAuth tools/list was captured before implementation: SUTI-Bridge-LivingMath 1.1.0-unified.1, 44 methods. No new method is installed or invented. Full initial schemas/health and protocol evidence are in `evidence/public-inventory/`.

Private acceptance reuses ARTIFACT-TRANSLATION-001's authenticated HTTP factory on BackupAPI clones, with 29 actual registered tools. The 002 client calls `record_result`, `dav_register_adapter`, `dav_check_law`, `dav_export_evidence`, `service_health`, and the existing history/integrity read. It examines tools/list before calls. No adapter/core/AST or transport source is changed.

Raw/source audit runs locally against the new owner-frozen byte catalog before target requests. The server stores H as unverified hypotheses; the report does not claim a new server-side semantic-audit endpoint. DAV registrations and evidence IDs are real, scoped to `LM_QA_GENESIS_002`. Synthetic mathematical calibration is identified separately; no fake registered source object or physical permission is produced.

New files are an additive experiment package, not a parallel persistent research server. The temporary QA process is terminated after acceptance. G3 is not established, so production installation is outside this task's authorized experimental scope.
